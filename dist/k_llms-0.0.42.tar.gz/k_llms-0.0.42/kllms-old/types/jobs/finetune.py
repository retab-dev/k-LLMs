# from pydantic import BaseModel
# from .batch_annotation import InferenceSettings

# class FineTuningInputData(BaseModel):
#     dataset_id: str
#     finetuning_props : FinetuningProps
